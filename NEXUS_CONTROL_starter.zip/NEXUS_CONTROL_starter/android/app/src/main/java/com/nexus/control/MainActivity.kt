package com.nexus.control

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import okhttp3.*
import org.json.JSONObject
import java.security.SecureRandom

class MainActivity : Activity() {
    // Ganti alamat ini jika Worker kamu memakai nama/domain lain.
    private val SERVER_BASE = "wss://nexus-ai-server.jorjordi093.workers.dev/room/"
    private val client = OkHttpClient()
    private var socket: WebSocket? = null
    private lateinit var status: TextView
    private lateinit var codeInput: EditText
    private var currentRole = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(Color.rgb(13, 18, 30))
        }
        val title = TextView(this).apply {
            text = "NEXUS CONTROL"
            textSize = 27f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Remote pairing • Consent-based device link"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Belum terhubung"
            textSize = 15f
            setTextColor(Color.rgb(130, 210, 170))
            setPadding(0, 28, 0, 18)
        }
        codeInput = EditText(this).apply {
            hint = "Masukkan kode 6 digit"
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(codeInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(makeButton("Jadi Penerima") { startReceiver() })
        root.addView(makeButton("Hubungkan sebagai Pengontrol") { startController() })
        root.addView(makeButton("Putuskan koneksi") {
            socket?.close(1000, "User disconnected")
            socket = null
            status.text = "Koneksi diputus."
        })
        root.addView(makeButton("Kirim demo Jumpscare") {
            if (currentRole == "controller" && socket != null) {
                send(JSONObject().put("type", "command").put("command", "jumpscare"))
            } else {
                status.text = "Hubungkan sebagai pengontrol dahulu."
            }
        })
        val note = TextView(this).apply {
            text = "HP penerima harus menyetujui pairing. Perintah demo ditampilkan secara terlihat."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, 22, 0, 0)
        }
        root.addView(note)
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
    }

    private fun startReceiver() {
        val code = (100000 + SecureRandom().nextInt(900000)).toString()
        codeInput.setText(code)
        currentRole = "receiver"
        connect(code, "receiver")
    }

    private fun startController() {
        val code = codeInput.text.toString().trim()
        if (!code.matches(Regex("[0-9]{6}"))) {
            status.text = "Masukkan kode 6 digit dari HP penerima."
            return
        }
        currentRole = "controller"
        connect(code, "controller")
    }

    private fun connect(code: String, role: String) {
        socket?.close(1000, "Reconnect")
        status.text = "Menghubungkan..."
        val request = Request.Builder().url("$SERVER_BASE$code?role=$role").build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread {
                    status.text = if (role == "receiver") {
                        "Kode penerima: $code — menunggu pengontrol"
                    } else {
                        "Terhubung. Mengirim permintaan pairing..."
                    }
                }
                if (role == "controller") {
                    webSocket.send(JSONObject().put("type", "pair_request").toString())
                }
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val data = try { JSONObject(text) } catch (_: Exception) { return }
                when (data.optString("type")) {
                    "pair_request" -> runOnUiThread { askPairApproval(webSocket) }
                    "pair_accepted" -> runOnUiThread { status.text = "Pairing disetujui. Koneksi aktif." }
                    "pair_rejected" -> runOnUiThread { status.text = "Permintaan pairing ditolak." }
                    "command" -> runOnUiThread { showCommand(data.optString("command")) }
                    "connected" -> runOnUiThread { status.text = data.optString("message") }
                    "error" -> runOnUiThread { status.text = data.optString("message") }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { status.text = "Gagal terhubung: ${t.message ?: "periksa server/internet"}" }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                runOnUiThread { status.text = "Koneksi ditutup." }
            }
        })
    }

    private fun askPairApproval(ws: WebSocket) {
        AlertDialog.Builder(this)
            .setTitle("Permintaan koneksi")
            .setMessage("Perangkat lain meminta terhubung ke HP ini. Izinkan?")
            .setPositiveButton("Terima") { _, _ ->
                ws.send(JSONObject().put("type", "pair_accepted").toString())
                status.text = "Pairing disetujui."
            }
            .setNegativeButton("Tolak") { _, _ ->
                ws.send(JSONObject().put("type", "pair_rejected").toString())
                status.text = "Pairing ditolak."
            }
            .setCancelable(false)
            .show()
    }

    private fun showCommand(command: String) {
        if (command == "jumpscare") {
            AlertDialog.Builder(this)
                .setTitle("NEXUS — DEMO JUMPSCARE")
                .setMessage("BOO! Ini hanya perintah demo yang terlihat.")
                .setPositiveButton("Tutup", null)
                .show()
        } else {
            status.text = "Perintah tidak dikenal."
        }
    }

    private fun send(data: JSONObject) {
        val ok = socket?.send(data.toString()) ?: false
        status.text = if (ok) "Perintah dikirim." else "Tidak tersambung."
    }

    override fun onDestroy() {
        socket?.close(1000, "App closed")
        client.dispatcher.executorService.shutdown()
        super.onDestroy()
    }
}
