NEXUS CONTROL — STARTER MVP
===========================

Isi paket:
- Android app (satu APK, bisa memilih mode Pengontrol atau Penerima)
- Cloudflare Worker + Durable Object untuk relay pesan
- GitHub Actions workflow untuk membangun APK secara cloud

MVP ini hanya menyediakan pairing dengan persetujuan dan perintah demo yang terlihat.
Belum ada akses kamera, pembacaan notifikasi, pemantauan aplikasi, atau transfer MP4.
Fitur tersebut tidak boleh berjalan diam-diam; pengembangan selanjutnya harus memakai
izin Android yang jelas dan indikator yang terlihat.

LANGKAH 1 — Siapkan server Cloudflare
-------------------------------------
Worker lama kamu saat ini masih Hello World. Untuk mengubahnya:
1. Buat folder/repository GitHub baru bernama nexus-control.
2. Upload seluruh isi folder ini ke repository.
3. Di Cloudflare, buat Worker baru atau gunakan Worker nexus-ai-server yang sudah ada.
4. Aktifkan Durable Objects untuk Worker. Cara paling mudah dari Wrangler:
   - Buka terminal cloud (misalnya GitHub Codespaces) pada repository.
   - Jalankan: npm install
   - Jalankan: npx wrangler login
   - Jalankan: npx wrangler deploy
   Catatan: deploy pertama membuat Durable Object binding dan migration sesuai wrangler.toml.
5. URL server pada aplikasi diset ke:
   wss://nexus-ai-server.jorjordi093.workers.dev/room/
   Jika kamu memakai nama Worker berbeda, ubah SERVER_BASE di MainActivity.kt.

LANGKAH 2 — Bangun APK tanpa Android Studio di HP
-------------------------------------------------
1. Upload folder ini ke repository GitHub.
2. Buka tab Actions.
3. Pilih workflow "Build Android APK" lalu tekan Run workflow.
4. Setelah selesai, buka hasil run dan unduh artifact "nexus-control-debug-apk".
5. Instal APK di dua HP. Android mungkin meminta izin memasang aplikasi dari browser/file manager.

LANGKAH 3 — Uji dua HP
---------------------
1. Buka APK di kedua HP.
2. Di HP penerima, tekan "Jadi Penerima". APK membuat kode 6 digit.
3. Di HP pengontrol, masukkan kode itu lalu tekan "Hubungkan sebagai Pengontrol".
4. HP penerima akan menampilkan permintaan. Tekan Terima.
5. Setelah tersambung, pengontrol dapat mengirim perintah demo "Tampilkan Jumpscare".
   Ini menampilkan layar demo yang jelas, bukan memutar file MP4.

CATATAN
-------
- Kedua HP perlu internet.
- Kode pairing bukan nomor telepon dan tidak memberi akses otomatis.
- Penerima harus menyetujui setiap pairing baru.
- Jangan gunakan untuk mengakses perangkat orang lain tanpa izin.
