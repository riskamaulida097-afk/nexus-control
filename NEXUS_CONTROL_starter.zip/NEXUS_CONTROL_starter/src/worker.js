export class Room {
  constructor(ctx, env) {
    this.ctx = ctx;
    this.env = env;
  }

  async fetch(request) {
    if (request.headers.get("Upgrade") !== "websocket") {
      return new Response("NEXUS room relay is running.", { status: 200 });
    }

    const pair = new WebSocketPair();
    const client = pair[0];
    const server = pair[1];
    this.ctx.acceptWebSocket(server);

    const url = new URL(request.url);
    const role = url.searchParams.get("role") === "receiver" ? "receiver" : "controller";
    server.serializeAttachment({ role });

    server.send(JSON.stringify({
      type: "connected",
      role,
      message: "Terhubung ke relay NEXUS."
    }));

    return new Response(null, { status: 101, webSocket: client });
  }

  webSocketMessage(sender, message) {
    let data;
    try {
      data = JSON.parse(message);
    } catch {
      sender.send(JSON.stringify({ type: "error", message: "Pesan tidak valid." }));
      return;
    }

    const senderInfo = sender.deserializeAttachment() || {};
    const allowed = new Set(["pair_request", "pair_accepted", "pair_rejected", "command"]);
    if (!allowed.has(data.type)) {
      sender.send(JSON.stringify({ type: "error", message: "Jenis perintah tidak diizinkan." }));
      return;
    }

    if (data.type === "command" && senderInfo.role !== "controller") {
      sender.send(JSON.stringify({ type: "error", message: "Hanya pengontrol yang dapat mengirim perintah." }));
      return;
    }

    for (const socket of this.ctx.getWebSockets()) {
      if (socket === sender) continue;
      const info = socket.deserializeAttachment() || {};
      if (data.type === "pair_request" && info.role !== "receiver") continue;
      if (data.type === "command" && info.role !== "receiver") continue;
      if (data.type === "pair_accepted" || data.type === "pair_rejected") {
        if (info.role !== "controller") continue;
      }
      try { socket.send(JSON.stringify(data)); } catch {}
    }
  }

  webSocketClose(ws) {
    try { ws.close(); } catch {}
  }

  webSocketError(ws) {
    try { ws.close(1011, "Relay error"); } catch {}
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/health") {
      return Response.json({ ok: true, service: "NEXUS CONTROL relay" });
    }

    const match = url.pathname.match(/^\\/room\\/([0-9]{6})$/);
    if (!match) {
      return new Response("NEXUS CONTROL. Use /room/123456 or /health.", { status: 200 });
    }

    const id = env.ROOMS.idFromName(match[1]);
    return env.ROOMS.get(id).fetch(request);
  }
};
